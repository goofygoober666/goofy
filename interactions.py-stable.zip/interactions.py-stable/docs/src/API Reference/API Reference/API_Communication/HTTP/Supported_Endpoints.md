This is a list of endpoints that are supported by interactions.py. These methods are organised in sub-files of interactions/http_requests according to where they best fit.

!!! note
    The majority of the time you should never need to interact with these. They’re only documented for people contributing to interactions.py.

::: interactions.api.http.http_requests

::: interactions.api.gateway.state

::: interactions.models.discord.emoji

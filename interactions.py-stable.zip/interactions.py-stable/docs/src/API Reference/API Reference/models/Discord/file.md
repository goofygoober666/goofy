::: interactions.models.discord.file

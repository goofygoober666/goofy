::: interactions.models.discord.channel

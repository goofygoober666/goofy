::: interactions.models.discord.sticker

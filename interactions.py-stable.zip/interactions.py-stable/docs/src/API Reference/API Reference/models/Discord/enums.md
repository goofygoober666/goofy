::: interactions.models.discord.enums

::: interactions.models.discord.scheduled_event

::: interactions.models.discord.stage_instance

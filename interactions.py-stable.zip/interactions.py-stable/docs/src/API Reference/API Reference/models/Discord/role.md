::: interactions.models.discord.role

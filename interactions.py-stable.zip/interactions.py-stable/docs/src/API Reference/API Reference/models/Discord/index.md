---
search:
  exclude: true
---

# Discord Models Index

- [Activity](activity)
- [Application](application)
- [Asset](asset)
- [Base](base)
- [Channel](channel)
- [Color](color)
- [Components](components)
- [Embed](embed)
- [Emoji](emoji)
- [Entitlement](entitlement)
- [Enums](enums)
- [File](file)
- [Guild](guild)
- [Index](index)
- [Invite](invite)
- [Message](message)
- [Modals](modals)
- [Reaction](reaction)
- [Role](role)
- [Scheduled event](scheduled_event)
- [Snowflake](snowflake)
- [Stage instance](stage_instance)
- [Sticker](sticker)
- [Team](team)
- [Thread](thread)
- [Timestamp](timestamp)
- [User](user)
- [Voice state](voice_state)
- [Webhooks](webhooks)

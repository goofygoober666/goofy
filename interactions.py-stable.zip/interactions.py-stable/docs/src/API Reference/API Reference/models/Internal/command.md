::: interactions.models.internal.command

::: interactions.models.internal.annotations

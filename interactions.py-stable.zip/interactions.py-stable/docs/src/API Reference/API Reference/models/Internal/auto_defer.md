::: interactions.models.internal.auto_defer

---
search:
  exclude: true
---

# Models

Within these pages, you will find a list of all available models within interactions.py.

- [Discord](Discord)
    - Models representing Discord objects

- [Client](Internal)
    - Models for library constructs

- [Misc](Misc)
    - Models for constructs that fit neither category

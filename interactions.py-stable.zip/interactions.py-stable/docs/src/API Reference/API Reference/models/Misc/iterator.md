::: interactions.models.misc.iterator

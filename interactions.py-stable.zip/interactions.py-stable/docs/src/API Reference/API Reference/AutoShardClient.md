::: interactions.client.auto_shard_client
